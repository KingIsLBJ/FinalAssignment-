package com.example.pintu20;

import androidx.appcompat.app.AppCompatActivity;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void ToEasy(View view) {
        startActivity(new Intent(this,EasyActivity.class));
    }

    public void ToMedium(View view) {
        startActivity(new Intent(this,MediumActivity.class));
    }

    public void ToHard(View view) {
        startActivity(new Intent(this,HardActivity.class));
    }

    public void ToEnd(View view) {
        finish();
    }

}